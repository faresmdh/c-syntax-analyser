import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MyJFrame extends JFrame implements ActionListener {

    private JLabel statusLabel, errorLabel;
    private JPanel codeTokensPanel;
    private JTextArea inputTA;

    private final String TYPE_ID = "Identifiant";
    private final String TYPE_KEYWORD = "Mot cle";
    private final String TYPE_OPERATOR = "Operateur";
    private final String TYPE_LITERAL = "Literaux";
    private final String TYPE_ERROR = "Erreur";

    private final char TYPE = 't';
    private final char ID = 'i';
    private final char LIT = 'l';
    private final char IF = 'f';
    private final char ELSE = 'e';
    private final char WHILE = 'w';
    private final char DO = 'd';
    private final char RETURN = 'r';
    private final char CS = 's';

    public MyJFrame() {
        super();
        setSize(1000, 600);
        setResizable(true);
        setTitle("C code checker");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initProgram();
    }

    private void initProgram() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        //status panel
        JPanel statusPanel = new JPanel();
        statusPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        statusLabel = new JLabel("Enter code");
        statusLabel.setFont(new Font("calibri", Font.PLAIN, 40));
        statusPanel.add(statusLabel);
        //text area panel
        JPanel textAreaPanel = new JPanel();
        textAreaPanel.setLayout(new CardLayout());
        textAreaPanel.setBorder(BorderFactory.createTitledBorder("Write your code here..."));
        inputTA = new JTextArea();
        inputTA.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        inputTA.setFont(new Font("Consolas", Font.PLAIN, 16));
        inputTA.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                getTokens();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                getTokens();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                getTokens();
            }
        });
        JScrollPane sp = new JScrollPane(inputTA);
        textAreaPanel.add(sp);
        //tokens panel
        JPanel tokensPanel = new JPanel();
        tokensPanel.setBorder(BorderFactory.createTitledBorder("Tokens"));
        tokensPanel.setPreferredSize(new Dimension(300, 0));
        tokensPanel.setLayout(new BorderLayout());
        JPanel titlesPanel = new JPanel();
        titlesPanel.setLayout(new GridLayout(1, 3, 0, 0));
        JLabel l1 = new JLabel("Token");
        l1.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        l1.setBackground(Color.GRAY);
        l1.setOpaque(true);
        JLabel l2 = new JLabel("Type");
        l2.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        l2.setBackground(Color.GRAY);
        l2.setOpaque(true);
        JLabel l3 = new JLabel("Position");
        l3.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        l3.setBackground(Color.GRAY);
        l3.setOpaque(true);
        titlesPanel.add(l1);
        titlesPanel.add(l2);
        titlesPanel.add(l3);
        tokensPanel.add(titlesPanel, BorderLayout.NORTH);
        codeTokensPanel = new JPanel();
        codeTokensPanel.setLayout(new GridLayout(0, 3, 0, 0));
        JScrollPane sp2 = new JScrollPane(codeTokensPanel);
        tokensPanel.add(sp2, BorderLayout.CENTER);
        //errors panel
        JPanel errorPanel = new JPanel();
        errorPanel.setLayout(new FlowLayout(FlowLayout.LEFT,32,32));
        JButton checkBtn = new JButton("Check code");
        checkBtn.addActionListener(this);
        errorLabel = new JLabel("No errors");
        errorPanel.add(checkBtn);
        errorPanel.add(errorLabel);


        mainPanel.add(statusPanel, BorderLayout.NORTH);
        mainPanel.add(textAreaPanel, BorderLayout.CENTER);
        mainPanel.add(tokensPanel, BorderLayout.EAST);
        mainPanel.add(errorPanel, BorderLayout.SOUTH);
        setContentPane(mainPanel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        checkCode();
    }

    private void getTokens(){
        String expression = inputTA.getText();
        ArrayList<Token> tokens = tokeniser(expression);
        print_tokens(tokens);
    }

    private void checkCode() {
        String expression = inputTA.getText();
        ArrayList<Token> tokens = tokeniser(expression);
        print_tokens(tokens);
        if (validate_code(tokens)) {
            statusLabel.setText("Valid code");
            statusLabel.setBackground(Color.green);
        } else {
            statusLabel.setText("Invalid code");
            statusLabel.setBackground(Color.red);
        }
        statusLabel.setOpaque(true);
    }

    private boolean validate_code(ArrayList<Token> tokens) {
        Stack stack = new Stack();
        init_tack(stack);
        push(stack, '$');
        push(stack, 'S');
        for (int i = 0; i < tokens.size(); i++) {
            Token t = tokens.get(i);
            char sommet = pop(stack);
            System.out.println("Sommet -> " + sommet + " Token -> " + t.getToken());
            if (isNonTerminal(sommet)) {
                int line = get_line(sommet), column = get_column(t);
                int act = tra_tab[line][column];
                if (act == -1) {
                    errorLabel.setText("Error in token \""+t.getToken()+"\" at "+t.getPosition()+" position.");
                    return false;
                }
                take_action(stack, act);
                i--;
            } else {
                if (t.getToken().equals("$") && sommet == '$') {errorLabel.setText("No error");return true;}
                if (
                        !((sommet == TYPE && is_type(t.getToken()))
                                || (sommet == CS && is_comparing_symbol(t.getToken()))
                                || (sommet == ID && t.getType().equals(TYPE_ID))
                                || (sommet == LIT && t.getType().equals(TYPE_LITERAL))
                                || (sommet == IF && t.getToken().equals("if"))
                                || (sommet == ELSE && t.getToken().equals("else"))
                                || (sommet == WHILE && t.getToken().equals("while"))
                                || (sommet == RETURN && t.getToken().equals("return"))
                                || (sommet == DO && t.getToken().equals("do"))
                                || (sommet == tokens.get(i).getToken().charAt(0) && tokens.get(i).getToken().length() == 1))
                ) {
                    errorLabel.setText("Error in token \""+t.getToken()+"\" at "+t.getPosition()+" position.");
                    return false;
                }
            }
        }
        return true;
    }

    private void print_tokens(ArrayList<Token> tokens) {
        codeTokensPanel.removeAll();
        for (Token t : tokens) {
            JLabel token = new JLabel(t.getToken());
            JLabel type = new JLabel(t.getType());
            JLabel position = new JLabel(String.valueOf(t.getPosition()));
            token.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            type.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            position.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            codeTokensPanel.add(token);
            codeTokensPanel.add(type);
            codeTokensPanel.add(position);
        }
        codeTokensPanel.revalidate();
        codeTokensPanel.repaint();
    }

    private ArrayList<Token> tokeniser(String expression) {
        ArrayList<Token> tokens = new ArrayList<>();
        int i = 0;
        while (i < expression.length()) {
            if (expression.charAt(i) == '>' || expression.charAt(i) == '<' || expression.charAt(i) == '=' || expression.charAt(i) == '!') {
                if (i + 1 < expression.length() && expression.charAt(i + 1) == '=') {
                    String word = expression.charAt(i) + "" + expression.charAt(i + 1);
                    i += 2;
                    tokens.add(new Token(word, TYPE_OPERATOR, i));
                } else {
                    String word = expression.charAt(i) + "";
                    i++;
                    tokens.add(new Token(word, TYPE_OPERATOR, i));
                }
            } else if (is_operator(expression.charAt(i))) {
                String word = expression.charAt(i) + "";
                i++;
                tokens.add(new Token(word, TYPE_OPERATOR, i));
            } else if (is_alphabetic(expression.charAt(i)) || expression.charAt(i) == '_') {
                StringBuilder word = new StringBuilder();
                while (i < expression.length() && (is_alphabetic(expression.charAt(i)) || is_numeric(expression.charAt(i)) || expression.charAt(i) == '_')) {
                    word.append(expression.charAt(i));
                    i++;
                }
                if (is_id(word.toString())) {
                    if (is_keyword(word.toString())) tokens.add(new Token(word.toString(), TYPE_KEYWORD, i));
                    else tokens.add(new Token(word.toString(), TYPE_ID, i));
                } else {
                    tokens.add(new Token(word.toString(), TYPE_ERROR, i));
                    //error here
                    break;
                }
            } else if (is_numeric(expression.charAt(i))) {
                StringBuilder word = new StringBuilder();
                while (i < expression.length() && (is_numeric(expression.charAt(i)) || expression.charAt(i) == '.')) {
                    word.append(expression.charAt(i));
                    i++;
                }
                if (is_float(word.toString()) || is_int(word.toString())) {
                    tokens.add(new Token(word.toString(), TYPE_LITERAL, i));
                } else {
                    tokens.add(new Token(word.toString(), TYPE_ERROR, i));
                    //error here
                    break;
                }
            } else if (expression.charAt(i) == '\'') {
                StringBuilder word = new StringBuilder("'");
                i++;
                while (i < expression.length() && expression.charAt(i) != '\'') {
                    word.append(expression.charAt(i));
                    i++;
                }
                word.append("'");
                i++;
                if (i < expression.length() && expression.charAt(i) == '\0' || !is_char(word.toString())) {
                    if (expression.charAt(i) == '\0') {
                    }
                    tokens.add(new Token(word.toString(), TYPE_ERROR, i));
                    //error here
                    break;
                } else {
                    tokens.add(new Token(word.toString(), TYPE_LITERAL, i));
                }
            } else if (expression.charAt(i) == '"') {
                StringBuilder word = new StringBuilder("\"");
                i++;
                while (i < expression.length() && expression.charAt(i) != '"') {
                    word.append(expression.charAt(i));
                    i++;
                }
                word.append("'");
                i++;
                if (i < expression.length() && expression.charAt(i) == '\0' || !is_str(word.toString())) {
                    tokens.add(new Token(word.toString(), TYPE_ERROR, i));
                    //error here
                    break;
                } else {
                    tokens.add(new Token(word.toString(), TYPE_LITERAL, i));
                }
            } else if (is_space(expression.charAt(i))) {
                i++;
            } else {
                String word = "" + expression.charAt(i);
                tokens.add(new Token(word, TYPE_ERROR, i));
                //error here
                break;
            }
        }
        return tokens;
    }

    private void take_action(Stack stack, int action) {
        switch (action) {
            case 1:
                push(stack, 'S');
                push(stack, '}');
                push(stack, 'B');
                push(stack, '{');
                push(stack, ')');
                push(stack, 'P');
                push(stack, '(');
                push(stack, ID);
                push(stack, TYPE);
                break; // S -> type id(P){B}S | #
            case 2:
                break; // S -> #
            case 3:
                push(stack, 'F');
                push(stack, ID);
                push(stack, TYPE);
                break; //P -> type idF
            case 4:
                break; // P -> #
            case 5:
                push(stack, 'F');
                push(stack, ID);
                push(stack, TYPE);
                push(stack, ',');
                break; // F -> ,type idF
            case 6:
                break; // F -> #
            case 7:
                push(stack, 'B');
                push(stack, 'D');
                break; //B -> DB
            case 8:
                push(stack, 'B');
                push(stack, 'E');
                break; //B -> EB
            case 9:
                push(stack, 'B');
                push(stack, 'C');
                break; //B -> CB
            case 10:
                push(stack, 'B');
                push(stack, 'L');
                break; //B -> LB
            case 11:
                push(stack, ';');
                push(stack, 'E');
                push(stack, RETURN);
                break; // B -> return E;
            case 12:
                break; // B -> #
            case 13:
                push(stack, ';');
                push(stack, 'E');
                push(stack, '=');
                push(stack, ID);
                push(stack, TYPE);
                break; // D -> type id = E;
            case 14:
                push(stack, 'X');
                push(stack, 'Y');
                break; // E -> YX
            case 15:
                push(stack, 'X');
                push(stack, 'Y');
                push(stack, '+');
                break; // X -> +YX
            case 16:
                push(stack, 'X');
                push(stack, 'Y');
                push(stack, '-');
                break; // X -> -YX
            case 17:
                push(stack, 'X');
                push(stack, 'Y');
                push(stack, '*');
                break; // X -> *YX
            case 18:
                push(stack, 'X');
                push(stack, 'Y');
                push(stack, '/');
                break; // X -> /YX
            case 19:
                push(stack, 'X');
                push(stack, 'Y');
                push(stack, '%');
                break; // X -> %YX
            case 20:
                break; // X -> #
            case 21:
                push(stack, ID);
                break; // Y -> id
            case 22:
                push(stack, LIT);
                break; // Y -> const
            case 23:
                push(stack, ')');
                push(stack, 'E');
                push(stack, '(');
                break; // Y -> (E)
            case 24:
                push(stack, 'A');
                push(stack, '}');
                push(stack, 'B');
                push(stack, '{');
                push(stack, ')');
                push(stack, 'Q');
                push(stack, '(');
                push(stack, IF);
                break; //C -> if(Q){B}A
            case 25:
                push(stack, 'T');
                push(stack, ELSE);
                break; //A -> else T
            case 26:
                break; //A -> #
            case 27:
                push(stack, 'A');
                push(stack, '}');
                push(stack, 'B');
                push(stack, '{');
                push(stack, ')');
                push(stack, 'Q');
                push(stack, '(');
                push(stack, IF);
                break; //T -> if(Q){B}A
            case 28:
                push(stack, '}');
                push(stack, 'B');
                push(stack, '{');
                break; //T -> {B}
            case 29:
                push(stack, '}');
                push(stack, 'B');
                push(stack, '{');
                push(stack, ')');
                push(stack, 'Q');
                push(stack, '(');
                push(stack, WHILE);
                break; // L -> while(Q){B}
            case 30:
                push(stack, ';');
                push(stack, ')');
                push(stack, 'Q');
                push(stack, '(');
                push(stack, WHILE);
                push(stack, '}');
                push(stack, 'B');
                push(stack, '{');
                push(stack, DO);
                break; // L -> do{B}while(Q)
            case 31:
                push(stack, 'E');
                push(stack, CS);
                push(stack, 'E');
                break; // Q -> E cs E
        }
    }

    int get_line(char c) {
        switch (c) {
            case 'S':
                return 0;
            case 'P':
                return 1;
            case 'F':
                return 2;
            case 'B':
                return 3;
            case 'D':
                return 4;
            case 'E':
                return 5;
            case 'X':
                return 6;
            case 'Y':
                return 7;
            case 'C':
                return 8;
            case 'A':
                return 9;
            case 'T':
                return 10;
            case 'L':
                return 11;
            case 'Q':
                return 12;
            default:
                return -1;
        }
    }

    int get_column(Token token) {
        if (token.getType().equals(TYPE_ID)) return 1;
        if (token.getType().equals(TYPE_KEYWORD)) {
            if (token.getToken().equals("return")) return 7;
            if (token.getToken().equals("if")) return 8;
            if (token.getToken().equals("else")) return 9;
            if (token.getToken().equals("while")) return 10;
            if (token.getToken().equals("do")) return 11;
            return 0;
        }
        if (token.getType().equals(TYPE_OPERATOR)) {
            if (token.getToken().equals("(")) return 3;
            if (token.getToken().equals(")")) return 4;
            if (token.getToken().equals("{")) return 5;
            if (token.getToken().equals("}")) return 6;
            if (token.getToken().equals("+")) return 12;
            if (token.getToken().equals("-")) return 13;
            if (token.getToken().equals("*")) return 14;
            if (token.getToken().equals("/")) return 15;
            if (token.getToken().equals("%")) return 16;
            if (token.getToken().equals(";")) return 17;
            if (is_comparing_symbol(token.getToken())) return 18;
            if (token.getToken().equals(",")) return 19;
        }
        if (token.getType().equals(TYPE_LITERAL)) return 2;
        if (token.getToken().equals("$")) return 1;
        return -1;
    }

    int[][] tra_tab = {
            {1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 2},
            {3, -1, -1, -1, 4, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 4},
            {3, -1, -1, -1, 6, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, 6},
            {7, 8, 8, 8, -1, -1, 12, 11, 9, -1, 10, 10, -1, -1, -1, -1, -1, -1, -1, 5, 12},
            {13, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, 14, 14, 14, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, 20, -1, -1, -1, -1, -1, -1, -1, 15, 16, 17, 18, 19, 20, 20, -1, 20},
            {-1, 21, 22, 23, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, -1, -1, -1, -1, 24, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {26, 26, 26, 26, -1, -1, 26, 26, 26, 25, 26, 26, -1, -1, -1, -1, -1, -1, -1, -1, 26},
            {-1, -1, -1, -1, -1, 28, -1, -1, 27, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 29, 30, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, 31, 31, 31, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
    };

    boolean is_comparing_symbol(String word) {
        return word.equals(">") || word.equals("<") || word.equals(">=") || word.equals("<=") || word.equals("==") || word.equals("!=");
    }

    private boolean isNonTerminal(char c) {
        return c == 'P' || c == 'F' || c == 'B' || c == 'S' || c == 'D' || c == 'E' || c == 'X' || c == 'Y' || c == 'C' || c == 'A' || c == 'T' || c == 'L' || c == 'Q';
    }

    static boolean is_type(String word) {
        return word.equals("int") || word.equals("float") || word.equals("char") || word.equals("void");
    }

    char pop(Stack stack) {
        return stack.elements[stack.sommet--];
    }

    void push(Stack stack, char element) {
        stack.elements[++stack.sommet] = element;
    }

    boolean is_Empty(Stack stack) {
        return stack.sommet == -1;
    }

    void init_tack(Stack stack) {
        stack.elements = new char[1000];
        stack.sommet = -1;
    }

    private boolean is_operator(char c) {
        return c == ',' || c == '>' || c == '<' || c == '=' || c == '+' || c == '-' || c == '*' || c == '/' || c == '%' || c == '!' || c == '(' || c == ')' || c == '{' || c == '}' || c == ';' || c == '&' || c == '|';
    }

    private boolean is_alphabetic(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    private boolean is_numeric(char c) {
        return (c >= '0' && c <= '9');
    }

    private boolean is_space(char c) {
        return c == ' ' || c == '\n' || c == '\t';
    }

    private boolean is_keyword(String keyword) {
        return keyword.equals("int") || keyword.equals("void") || keyword.equals("float") || keyword.equals("char")
                || keyword.equals("if") || keyword.equals("else") || keyword.equals("while") || keyword.equals("return");
    }

    private boolean is_id(String keyword) {
        int[][] tra_table = {
                {0, 1, 2, 3, 3},
                {1, 1, 1, 1, 3},
                {2, 2, 2, 2, 3},
                {3, 3, 3, 3, 3}
        };
        int current_state = 0;
        int i = 0, symbol_type;
        while (current_state != 3 && i < keyword.length()) {
            if (keyword.charAt(i) == '_') symbol_type = 1;
            else if (is_alphabetic(keyword.charAt(i))) symbol_type = 2;
            else if (is_numeric(keyword.charAt(i))) symbol_type = 3;
            else symbol_type = 3;
            current_state = tra_table[current_state][symbol_type];
            i++;
        }
        return current_state == 1 || current_state == 2;
    }

    private boolean is_int(String keyword) {
        int[][] tra_table = {
                {0, 1, 2},
                {1, 1, 2},
                {2, 2, 2}
        };
        int current_state = 0;
        int i = 0, symbol_type;
        while (current_state != 2 && keyword.charAt(i) != '\0') {
            if (is_numeric(keyword.charAt(i))) symbol_type = 1;
            else symbol_type = 2;
            current_state = tra_table[current_state][symbol_type];
            i++;
        }
        return current_state == 1;
    }

    private boolean is_float(String keyword) {
        int[][] tra_table = {
                {0, 1, 3, 4},
                {1, 1, 2, 4},
                {2, 3, 4, 4},
                {3, 3, 4, 4},
                {4, 4, 4, 4}
        };
        int current_state = 0;
        int i = 0, symbol_type;
        while (current_state != 4 && i < keyword.length()) {
            if (is_numeric(keyword.charAt(i))) symbol_type = 1;
            else if (keyword.charAt(i) == '.') symbol_type = 2;
            else symbol_type = 3;
            current_state = tra_table[current_state][symbol_type];
            i++;
        }
        return current_state == 1 || current_state == 3;
    }

    private boolean is_char(String keyword) {
        int[][] tra_table = {
                {0, 1, 4, 4},
                {1, 4, 2, 4},
                {2, 3, 4, 4},
                {3, 4, 4, 4},
                {4, 4, 4, 4}
        };
        int current_state = 0;
        int i = 0, symbol_type;
        while (current_state != 4 && keyword.charAt(i) != '\0') {
            if (keyword.charAt(i) == '\'') symbol_type = 1;
            else if (keyword.charAt(i) <= 127) symbol_type = 2;
            else symbol_type = 3;
            current_state = tra_table[current_state][symbol_type];
            i++;
        }
        return current_state == 3;
    }

    private boolean is_str(String word) {
        int[][] tra_table = {
                {0, 1, 4, 4},
                {1, 4, 2, 4},
                {2, 3, 2, 4},
                {3, 4, 4, 4},
                {4, 4, 4, 4}
        };
        int current_state = 0;
        int i = 0, symbol_type;
        while (current_state != 4 && word.charAt(i) != '\0') {
            if (word.charAt(i) == 34) symbol_type = 1;
            else if (word.charAt(i) <= 127) symbol_type = 2;
            else symbol_type = 3;
            current_state = tra_table[current_state][symbol_type];
            i++;
        }
        return current_state == 3;
    }
}
