public class Stack {
    char elements[];
    int sommet;

    public char[] getElements() {
        return elements;
    }

    public void setElements(char[] elements) {
        this.elements = elements;
    }

    public int getSommet() {
        return sommet;
    }

    public void setSommet(int sommet) {
        this.sommet = sommet;
    }
}
